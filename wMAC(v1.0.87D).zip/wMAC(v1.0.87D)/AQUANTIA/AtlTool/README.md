# Version 4.11

# Table of Contents

 * [Pre-built Binaries](#pre-built-binaries)
 * [Supported Platforms](#supported-platforms)
 * [Supported Hardware](#supported-hardware)
 * [Interfaces](#interfaces)
 * [Tools](#tools)
 * [Flash Tools](#flash-tools)
 * [Test Tools](#test-tools)
 * [Other Tools](#other-tools)

# Pre-built Binaries

 * [Latest](http://qa-nfs01.rdc.aquantia.com/builds/tools/atlantic2/latest/)
 * [All versions](http://qa-nfs01.rdc.aquantia.com/builds/tools/atlantic2/)

# Supported Platforms

 * Windows x86
 * Windows x86_64
 * Linux x86_64
 * Linux arm
 * Linux aarch64
 * Linux PowerPC
 * FreeBSD x86_64
 * macOS x86_64
 * QNX x86_64
 * QNX aarch64
 * Android x86_64
 * Android arm
 * Android aarch64
 * DOS i386
 * UEFI x86_64
 * UEFI aarch64
 * ESXi x86_64

# Supported Hardware

 * AQC113

# Pre Requirements

 * Make sure `PATH` environment variable for Windows systems or `LD_LIBRARY_PATH` environment variable for Linux systems or `DYLD_LIBRARY_PATH` environment variable for macOs points to the directory where shared libraries are located.

# Interfaces

## PCI

 * **Library**: `hwInterfaceAtltool`
 * **Family name**: `PCI`

Access Aquantia devices through PCI. Devices are located by Vendor ID 0x1D6A.

Note: super-user (administrator) privileges are required.

### Dependencies

 * `libatlpci` shared library

### Linux with strict memory access

If the tools fail with the following error:

```
Error: atlaccess driver is not loaded
```

that means, the tools failed to access device's registers from user space. In order to fix that issue, user can try following steps:

 1. `tar xzf atlaccess.tar.gz`
 2. `cd atlaccess/`
 3. `make`
 4. `sudo insmod atlaccess.ko`

## PCI using diagnostic driver

 * **Library**: `hwInterfacePCI`
 * **Family name**: `DIAG`

Access Aquantia devices through PCI. Diagnostic driver must be installed and binded to PCI device.

Diagnostic driver builds: [here](http://qa-nfs01.rdc.aquantia.com/builds/driver/diag/).

### Dependencies

 * Running diagnostic driver

## BeagleBone

 * **Library**: `hwInterfaceBB`
 * **Family name**: `BB`

Access Aquantia devices using BeagleBone board through SMBUS or MDIO.

### Pre Requirements

Make sure 12345 UDP port is open for communication.

For example, you can do that on Linux systems by executing next command:

```
sudo iptables -I INPUT -p udp --dport 12345 -j ACCEPT
```

### Dependencies for Windows

 * `oncrpc` shared library. License: LGPL 2.1.

### Dependencies for Linux

 * `libtirpc` shared library. License: BSD 3-clause.

## T6

 * **Library**: `hwInterfaceFTDI`
 * **Family name**: `T6`

Access Aquantia devices using T6 board through SMBUS or MDIO.

### Pre Requirements

After connecting T6 device to Linux machine make sure to unload default FTDI driver:

```
sudo rmmod ftdi_sio
```

To change I2C clock, you can use `I2C_CLOCK_HZ` environment variable. Default is 400 kHz.

For example:

```
sudo I2C_CLOCK_HZ=100000 ./atltool2 -d AQT6B0088:I2C -rr 0x18
```

### Dependencies

 * `libftd2xx` library (statically linked). License: FTDriver license (http://www.ftdichip.com/Drivers/FTDriverLicenceTermsSummary.htm).

## TCP

 * **Library**: `hwInterfaceTCP`
 * **Family name**: `TCP`

Access Aquantia devices through TCP connection to server running on a remote host.

### Dependencies

 * `tcpServer` running on a remote host.

# Tools

## listDevices

Enumerates available devices using chosen interface. These device names should be passed to other tools.

```
Usage: listDevices [-d FAMILY]

Options:

    -h, --help Display help message.

    -d FAMILY  Device family. Choises: PCI, T6, BB, TCP, DIAG.
               Default: PCI.
```

 * PCI devices name notation:

   `[[[DOMAIN-]BUS]:][DEVICE][.[FUNCTION]]` - where `DOMAIN`, `BUS`, `DEVICE`, `FUNCTION` - are PCI domain, bus, device and function numbers accordingly. You can also use `lspci` tool to enumerate PCI devices in system.

   For example, next notations describe the same device:

    * `0001-02:00.0`
    * `1-2:0.0`
    * `1-2:`

 * BeagleBone devices name notation:

   `DEVICE:PORT` - `PORT` should be one of the following: `0`, `11`, `12`.

 * T6 devices name notation:

   `DEVICE:MODE` - `MODE` should be one of the following: `I2C`, `MDIO`.

 * TCP devices name notation:

   `TCP[IP,DEVICE]` - where `IP` - IP address of the server, `DEVICE` - device name on that server (depends on kind of TCP server running on remote host).

### Examples

```
# listDevices -d PCI

Available devices for PCI family:
    0000-01:00.0
    0000-04:00.0
```

```
# listDevices -d TCP

Available devices for TCP family:
    Available devices on at136-h170 server:
        TCP[172.30.1.145,0000-04:00.0]
```

## atltool2

Read / write MAC, PHY, MSM registers of Antigua chip.

```
Usage: atltool2 [-d DEVICE] [-t TYPE] [-dev_id DEV_ID] [-phy_id PHY_ID] [-i]
                [-rr MACREG] [-wr MACREG VALUE] [-rr64 MACREG] [-wr64 MACREG VALUE]
                [-rpr PHYREG] [-wpr PHYREG VALUE] [-rmsm MACREG] [-wmsm MACREG VALUE]
                [-rnmsm MACREG] [-wnmsm MACREG VALUE] [-rm ADDR [SIZE]] [-rpm ADDR [SIZE]]

Options:

    -h, --help          Display help message.

    -d DEVICE           Device name from listDevices tool.
                        You can use shortcuts to access the first device
                        in a family: PCI, T6, BB, TCP, DIAG.
    -t TYPE             Device type. By default program tries to detect device
                        type by analyzing DEVICE name.
                        You can specify one of the following: PCI, T6, BB, TCP, DIAG.

    -i                  Connect to device and run an interactive shell.
                        All below commands will work. Minus sign can be omitted.

    -dev_id DEV_ID      MAC device ID. Default: 0x79 for SMBus, 0x0 otherwise.
    -phy_id PHY_ID      PHY device ID. By default the program will try to
                        detect it automatically.
    -rr MACREG          Read MAC registers (32-bit).
    -wr MACREG VALUE    Write MAC registers (32-bit).
    -rr64 MACREG        Read MAC registers (64-bit).
    -wr64 MACREG VALUE  Write MAC registers (64-bit).
    -rpr PHYREG         Read PHY registers.
    -wpr PHYREG VALUE   Write PHY register.
    -rm ADDR [SIZE]     Read MCP memory from address ADDR. Default SIZE=4.
    -rpm ADDR [SIZE]    Read PHY memory from address ADDR. Default SIZE=4.
    -rmsm MACREG        Read MSM registers.
    -wmsm MACREG VALUE  Write MSM registers.
    -rnmsm MACREG       Read NCSI MSM registers.
    -wnmsm MACREG VALUE Write NCSI MSM registers.

Register formats:

    MACREG:
        ADDR1           - MAC register ADDR1.
        ADDR1:ADDR2     - MAC registers ADDR1-ADDR2 inclusive.
        ADDR1.BIT1      - Bit BIT1 of MAC register ADDR1.
        ADDR1.BIT2:BIT1 - Bits BIT1-BIT2 inclusive of MAC register ADDR1.
    PHYREG:
        MMD1.ADDR1            - PHY register MMD1.ADDR1.
        MMD1.ADDR1:MMD1.ADDR2 - PHY registers MMD1.ADDR1-MMD1.ADDR2 inclusive.
        MMD1.ADDR1.BIT1       - Bit BIT1 of PHY register MMD1.ADDR1.
        MMD1.ADDR1.BIT2:BIT1  - Bits BIT1-BIT2 inclusive of PHY register MMD1.ADDR1.
```

### Examples

 * `atltool2 -d 1: -wr 0x368 0xF20` - write `0xF20` to `0x368` MAC register on PCI device `1:`.
 * `atltool2 -d AQT6B0088:I2C -rr 0x368:0x374` - read MAC registers `0x368` through `0x374` from device connected to T6 device `AQT6B0088:I2C`.
 * `atltool2 -d JS12V0B004:11 -rm 0x1FB2BE00 8` - read 8 bytes from MCP memory starting at offset `0x1FB2BE00` from device connected to BeagleBone device `JS12V0B004:11`.
 * `atltool2 -d AQT6B0088:I2C -dev_id 0x5A -rr 0x10000` - read register `0x10000` from device connected to T6 device `AQT6B0088:I2C` with SMBus slave address `0x5A`.

## readlog2

### Dependencies

* `libyaml` library (statically linked).

Read MAC firmware logs and save them to binary file / parse into text form.

```
Usage: readlog2 [-d DEVICE | -f INPUTFILE] [-t TYPE] [-p[=YAML]] [-b BINFILE]
                [-o TXTFILE] [-n]

Options:

    -h, --help   Display help message.

    -d DEVICE    Device name from listDevices tool.
                 You can use shortcuts to access the first device
                 in a family: PCI, T6, BB, TCP, DIAG.
    -t TYPE      Device type. By default program tries to detect device
                 type by analyzing DEVICE name.
                 You can specify one of the following: PCI, T6, BB, TCP, DIAG.
    -f INPUTFILE Binary file to parse logs from (implies -p option).
    -p[=YAML]    Turn on live log parsing into text. If YAML is specified, use
                 this yaml config file instead of default mdbgconstants.yaml.
    -b BINFILE   Path to the binary output log file. Default: a2_trace.bin.
    -o TXTFILE   Path to the text output log file. Default: stdout.
    -n TIMEOUT   Timeout in seconds for capturing FW logs.
                 Default: Press CTRL+C to exit loop.
```

### Examples

 * `readlog2 -d 1:` - collect binary MAC FW log to `a2_trace.bin` file.
 * `readlog2 -d 1: -p` - collect binary MAC FW log to `a2_trace.bin` file, parse it into text using `mdbgconstants.yaml` file and print to the console.
 * `readlog2 -d 1: -p=fw/mdbg_0.0.19.yaml -o log.txt` - collect binary MAC FW log to `a2_trace.bin` file, parse it into text using `fw/mdbg_0.0.19.yaml` file and save it to `log.txt` file.

## readstat2

Print information about Antigua chip, running FW.

```
Usage: readstat2 [-d DEVICE] [-t TYPE] [-p] [--msm] [--phy] [--dma] [--tpo]
                 [--rpf_cnt] [--rpf_res] [--mac] [--fw_drv] [--fw_cfg]
                 [--snps] [--minisif] [--ncsi]

Options:

    -h, --help Display help message.

    -d DEVICE  Device name from listDevices tool.
               You can use shortcuts to access the first device
               in a family: PCI, T6, BB, TCP, DIAG.
    -t TYPE    Device type. By default program tries to detect device
               type by analyzing DEVICE name.
               You can specify one of the following: PCI, T6, BB, TCP, DIAG.
    -p         Print information about PHY only.

Counters and statistics (multiple choice):

    --msm      Print MSM counters.
    --phy      Print PHY counters.
    --dma      Print TDM and RDM counters.
    --tpo      Print TPO counters.
    --rpf_cnt  Print RPF counters.
    --rpf_res  Print RPF Action Resolver table.
    --mac      Print additional MAC counters (TKL/RKL, TSI/RSI).
    --fw_drv   Print firmware statistics and capabilities.
    --fw_cfg   Print firmware config (MAC BDP).
    --snps     Print PCIe SerDes statistics.
    --minisif  Print PHY Mini SIF counters (Antigua B0 only).
    --ncsi     Print NCSI counters.
```

### Examples

 * `readstat2 -d 1:` - print basic information about Antigua hardware (MAC, PHY, PCI).
 * `readstat2 -d 1: -p` - print information about Antigua PHY (RHEA).
 * `readstat2 -d 1: --msm` - print Atlantic 2 MSM block counters.
 * `readstat2 -d 1: --tpo --rpf_cnt` - print Atlantic 2 TPO and RPF blocks counters.

## kickstart2

Reset Antigua chip and make sure MAC and PHY firmware is loaded.

```
Usage: kickstart2 [-d DEVICE] [-t TYPE] [-c CLX] [-f] [-a] [-p] [-i ITI] [-r]
                  [-g] [-s] [-v]

Options:

    -h, --help Display help message.

    -d DEVICE  Device name from listDevices tool.
               You can use shortcuts to access the first device
               in a family: PCI, T6, BB, TCP, DIAG.
    -t TYPE    Device type. By default program tries to detect device
               type by analyzing DEVICE name.
               You can specify one of the following: PCI, T6, BB, TCP, DIAG.
    -c CLX     CLX file for boot from host.
    -f         Request flashless boot.
    -a         Request fast boot.
    -p         Request to skip PHY reset.
    -i ITI     Request loading Init-Time Instructions from host with ITI file.
    -r         Do <Full Reset (0x3000)> instead of <Global Reset (0x3040)>.
    -g         Do <Chip Reset (0x3080)> instead of <Global Reset (0x3040)>.
    -s         Don't wait for PHY FW to start up.
    -v         Verbose output.
```

### Examples

 * `kickstart2 -d 1:` - perform global reset.
 * `kickstart2 -d 1: -r -v` - perform full reset and be verbose.
 * `kickstart2 -d 1: -f -c ATL2-0.0.19.clx` - perform global reset, force boot from host and use `ATL2-0.0.19.clx` for boot.

## efuseRead2

Read eFuse data from Antigua chip.

```
Usage: efuseRead2 [-d DEVICE] [-t TYPE] [-s STARTDW] [-n NUMDW] [-f FORMAT]
                  [-v MASK]

Options:

    -h, --help Display help message.

    -d DEVICE  Device name from listDevices tool.
               You can use shortcuts to access the first device
               in a family: PCI, T6, BB, TCP, DIAG.
    -t TYPE    Device type. By default program tries to detect device
               type by analyzing DEVICE name.
               You can specify one of the following: PCI, T6, BB, TCP, DIAG.
    -s STARTDW Number of eFuse dword to start reading from. Default: 0.
    -n NUMDW   Maximum number of eFuse data dwords to read. Default: 192.
    -f FORMAT  Format in which to output eFuse.
               Choises: list, table, mem, mask.
               Default: table.
    -v MASK    Verify eFuse data against provided .mask file.
```

### Examples

 * `efuseRead2 -d 1:` - print full eFuse data as a list.
 * `efuseRead2 -d 1: -f table` - print full eFuse data as a table.
 * `efuseRead2 -d 1: -s 32 -n 160 -f mem` - print eFuse dwords `32-191` as `.mem` file.
 * `efuseRead2 -d 1: -v ATE.mask` - verify that eFuse data corresponds to data described in `ATE.mask` file.

## efuseBurn2

Burn eFuse data on Antigua chip.

.mem and .mask files are generated using `a2efuse` tool.

The tool reads current eFuse chip contents and applies values from provided config to it. Then it calculates
Error Correction Code for the first 32 dwords of eFuse data and places it to the first available slot for it
(dwords 28 and 29). To manually chose where ECC should be put use `-e` option. To skip ECC calculation use
`-n` option.

```
Usage: efuseBurn2 [-d DEVICE] [-t TYPE] [-e WORD] [-n] [-s] CONFIG [CONFIG ...]

Options:

    -h, --help Display help message.

    -d DEVICE  Device name from listDevices tool.
               You can use shortcuts to access the first device
               in a family: PCI, T6, BB, TCP, DIAG.
    -t TYPE    Device type. By default program tries to detect device
               type by analyzing DEVICE name.
               You can specify one of the following: PCI, T6, BB, TCP, DIAG.
    -e WORD    Force ECC correction word to be put into this position.
               Correct values are: 0, 1, 2, 3. 0 starting at LSW of dword 28.
               Default: first empty ECC word will be selected.
    -n         Don't calculate ECC correction word for eFuse dwords 0-31 and
               burn eFuse data as is.
    -s         Skip burning and proceed to verification.
    CONFIG     eFuse *.mem config files or single *.mask file.
```

### Examples

 * `efuseBurn2 -d 1: MAC_part.mem PHY_part.mem` - burn eFuse data described in `MAC_part.mem` and `PHY_part.mem` files.
 * `efuseBurn2 -d 1: ATE.mask` - burn eFuse data described in `ATE.mask` file.

## rblEfuseBurn2

Burn eFuse data on Antigua chip using RBL maintenance mode.

The tool resets Antigua chip into maintenance mode and sends commands prepared by `a2efuse` to RBL.

```
Usage: rblEfuseBurn2 [-d DEVICE] [-t TYPE] [-m MAC] [-n Srnum] [-e] CMD [CMD ...]

Options:

    -h, --help Display help message.

    -d DEVICE  Device name from listDevices tool.
               You can use shortcuts to access the first device
               in a family: PCI, T6, BB, TCP, DIAG.
    -t TYPE    Device type. By default program tries to detect device
               type by analyzing DEVICE name.
               You can specify one of the following: PCI, T6, BB, TCP, DIAG.
    -m MAC     MAC address to burn to eFuse.
    -n SrNum   SerialNumber to burn to eFuse, max len 24 characters.
    -e         Allow VDDQ and MAC address commands to be provided as binary
               files as well. Option -m and VDDQ ramp up / ramp down will
               not be executed. Only command files will be executed.
    CMD        List of RBL command files.
```

## serdesEye2

Collect Synopsys SerDes eye diagram and store raw data in JSON file.

Script serdes_eye.py should be used to parse the output data.

```
Usage: serdesEye2 [-d DEVICE] [-t TYPE] [-o FILE] --lane {0, 1, 2, 3}
                  [--stat_len [1-32768]]

Options:

    -h, --help Display help message.

    -d DEVICE  Device name from listDevices tool.
               You can use shortcuts to access the first device
               in a family: PCI, T6, BB, TCP, DIAG.
    -t TYPE    Device type. By default program tries to detect device
               type by analyzing DEVICE name.
               You can specify one of the following: PCI, T6, BB, TCP, DIAG.
    -o FILE    Name of output JSON file. If not provided, data will be
               printed to stdout.
    --lane {0, 1, 2, 3}
               Lane to be measured.
    --stat_len [1-32768]
               Number of samples for stats collection (maximum: 32768).
               Default: 2048.
```

### Examples

 * `serdesEye2 -d 0000-01:00.0 --lane 0` - collect SerDes eye diagram for lane 0 for PCI device `0000-01:00.0` and print raw data to the console.
   Number of samples for each cell is 2048.
 * `serdesEye2 -d 0000-01:00.0 --lane 2 -o sample2.json --stat_len 32768` - collect SerDes eye diagram for lane 2 for PCI device `0000-01:00.0` and
   dump raw data to `sample2.json` file. Number of samples for each cell is 32768.
 * `python serdes_eye.py sample.json` - plot and display SerDes eye diagram previously collected by `serdesEye2` tool.

# Flash Tools

## flashBurn2

Burn CLX image to flash.

```
Usage: flashBurn2 -d DEVICE [-t TYPE] [-a ADDRESS] FIRMWARE

Options:

    -h, --help Display help message.

    -d DEVICE  Device name from listDevices tool.
               You can use shortcuts to access the first device
               in a family: PCI, T6, BB, TCP, DIAG.
    -t TYPE    Device type. By default program tries to detect device
               type by analyzing DEVICE name.
               You can specify one of the following: PCI, T6, BB, TCP, DIAG.
    -a ADDRESS Write image to this FLASH address. If this option is not
               specified, the tool will perform full re-write of the FLASH.
               If option is specified, the tool will write image data
               preserving existing FLASH data.
    FIRMWARE   The image file to write to FLASH.
```

### Examples

 * `flashBurn2 -d 1: ATL2-0.0.19.clx` - burn `ATL2-0.0.19.clx` image to flash.

## flashDump2

Dump current flash content to file.

```
Usage: flashDump2 -d DEVICE [-t TYPE] [-a ADDRESS] [-s SIZE] [-o OUT_FILE_NAME]
                  [--clk_div CLKDIV]

Options:

    -h, --help       Display help message.

    -d DEVICE        Device name from listDevices tool.
                     You can use shortcuts to access the first device
                     in a family: PCI, T6, BB, TCP, DIAG.
    -t TYPE          Device type. By default program tries to detect device
                     type by analyzing DEVICE name.
                     You can specify one of the following: PCI, T6, BB, TCP, DIAG.
    -a ADDRESS       Read starting from this address. Default: 0.
    -s SIZE          Read only specified number of bytes. Format:
                     1M - Megabyte, 1K - Kilobyte, 1B - Byte.
                     Default: entire FLASH.
    -o OUT_FILE_NAME The file to write the FLASH content to. Default: stdout.
    --clk_div CLKDIV Set NVR Clock Divider to this value. Default: 16.
```

### Examples

 * `flashDump2 -d 1: -o dump.clx` - dump entire flash content to `dump.clx` file.
 * `flashDump2 -d 1: -a 0x10 -s 32` - print 32 bytes of flash data starting at offset 0x10 to the console.

## flashErase2

Erase current flash content.

```
Usage: flashErase2 -d DEVICE [-t TYPE]

Options:

    -h, --help Display help message.

    -d DEVICE  Device name from listDevices tool.
               You can use shortcuts to access the first device
               in a family: PCI, T6, BB, TCP, DIAG.
    -t TYPE    Device type. By default program tries to detect device
               type by analyzing DEVICE name.
               You can specify one of the following: PCI, T6, BB, TCP, DIAG.
```

### Examples

 * `flashErase2 -d 1:` - erase full flash content.

## flashVerify2

Verify burned to FLASH Antigua .clx image.

```
Usage: flashVerify2 [-d DEVICE] [-t TYPE] [--relaxed] [-m MASK]

Options:

    -h, --help Display help message.

    -d DEVICE  Device name from listDevices tool.
               You can use shortcuts to access the first device
               in a family: PCI, T6, BB, TCP, DIAG.
    -t TYPE    Device type. By default program tries to detect device
               type by analyzing DEVICE name.
               You can specify one of the following: PCI, T6, BB, TCP, DIAG.
    --relaxed  Allow relaxed signing and loading from the 2nd NCB.
               Default: False.
    -m MASK    eFuse .mask config file. If provided, public key will be
               verified against hash in eFuse dwords 184-191 (32 bytes).
```

### Examples

 * `flashVerify2 -d 1: -m ProdHash.mask` - verify that flash content meets production image requirements and verify security descriptor signature against hash provided in `ProdHash.mask` file.

# Test Tools

## ieeeTests2

IEEE tests.

```
Usage: ieeeTests2 -d DEVICE [--phy_id PHY_ID] -s SPEED --test-mode TEST
                  [--linearity-tone TONE]

Options:

    -h, --help          Display help message.
    -d DEVICE           Device name from listDevices tool.
    -s SPEED, --speed SPEED
                        PHY speed to set: 100M, 1G, 2.5G, 5G or 10G.
    --phy_id PHY_ID     PHY device ID. By default the program will try to
                        detect it automatically.
    --test-mode TEST    Test Mode number.
                            For 100M:
                                1 - IEEE Test Mode: MLT-3 Idle Sequence.
                                2 - ANSI Jitter Test.
                                3 - ANSI Droop Test.
                            For 1G:
                                1 - Transmit waveform test.
                                2 - Master transmit jitter test.
                                3 - Slave transmit jitter test.
                                4 - Transmitter distortion test.
                            For 2.5G, 5G and 10G:
                                1 - Master source for slave mode jitter test.
                                2 - Master mode jitter test.
                                3 - Slave mode jitter test.
                                4 - Transmitter distortion test.
                                5 - PSD and power level test.
                                6 - Transmitter Droop test.
                                7 - Pseudo random test mode for BER Monitor.
    --linearity-tone TONE
                        Linearity tone number (Transmitter Test Frequency).
                            For Test Mode 4 only (2.5G, 5G, 10G):
                                1 - Dual Tone #1.
                                2 - Dual Tone #2.
                                3 - Dual Tone #3.
                                4 - Dual Tone #4.
                                5 - Dual Tone #5.
```

## datapathTest2

Send/receive a stream of packets through full datapath and check its integrity.

### Prerequisites

 * External RJ45 loopback must be plugged in if this option is in use.
 * Linux SW requirements:
   - "aqdiag" driver must be loaded and bound to the device (it must replace regular "atlantic" driver).
   - aqdiag-src.tar.gz package contains separate README.txt on how to build and install it.

```
Usage: datapathTest2 -d DEVICE [--config datapath_config.yml] [-l LOOPBACK] [-t TIME] [-s SPEED] [-p PACKET_SIZE] 
                               [-r RING_SIZE] [--seed SEED] [-c ON|OFF] [--interactive] [--tx_only] [--rx_only]
                               [--link_timeout TIME] [--kickstart ON|OFF] [-n N] [--throughput THROUGHPUT]

Options:

    -h, --help                         Display help message.

    -d DEVICE                          Device name from "listDevices -d diag" command.
                                       Diagnostic driver must replace production driver for the device:
                                           Windows: aquantiaDiag
                                           Linux  : aqdiag
                                           UEFI   : no driver
                                       See README.txt for each of the above drivers (except UEFI).

    --config datapath_config.yml       YAML file with test parameters. Priority of applying test parameters:
                                       P1 - command line option (overrides both default value and YAML file value).
                                       P2 - YAML file value (overrides default value only).
                                       P3 - default value.

    -l, --loopback LOOPBACK            Set loopback: MAC_DMA, MAC_PKT, RJ45, NONE.
                                       Default: RJ45.
    Loopback descriptions:
        MAC_DMA - DMA System Loopback (bit fields 0x5000.6 and 0x7000.6) includes DMA engine only.
        MAC_PKT - PKT System Loopback (bit fields 0x5000.6 and 0x7000.6) includes TPO and RPF.
        RJ45    - External loopback that must be physically plugged in to RJ45 port.
        NONE    - This option requires back-to-back cable connection with paired device (link partner, or LKP).
                  Different device pairs like AQC107<->AQC113 or AQC111<->AQC108 are possible.
                  Non-AQC link partner can be used with option '--integrity_check OFF'.

    -t, --traffic_time TIME            Time of sending/receiving traffic in seconds.
                                       Default: 1 sec.

    -n, --max_packet_number N          Maximum number of packets to transmit (and then stop).
                                       Default: 0 (don't stop by packet number).

    -s, --speed SPEED                  Link rate: 10M, 100M, 1G, 2.5G, 5G or 10G.
                                       Default: 10G.

    -p, --packet_size (SIZE | MIN:MAX) Set packet size in bytes (a number or interval between 64 and 16352).
                                       Default: 1024 bytes.

    -r, --ring_size RING_SIZE          Set ring size (number of descriptors simultaneously used for Tx/Rx).
                                       Must be in range [8, 8184] with step by 8.
                                       Default: 8184 (512 on UEFI).

    --seed SEED                        Set fixed seed for randomizing packets length and payload.
                                       Use it to reproduce issues with
                                       the same sequence of pseudo-random packets.

    -c, --integrity_check ON|OFF       Enable/Disable checking packets integrity.
                                       Default: ON (OFF for ARM platform).

    --interactive                      Require pressing 'Enter' at some points of the test.

    --tx_only                          TX datapath test only.

    --rx_only                          RX datapath test only.

    --link_timeout TIME                Time of waiting link up (in seconds). Maximum is 300.

    --kickstart ON|OFF                 Perform/skip chip reset.
                                       Default: ON.
    
    --throughput THROUGHPUT            Minimal acceptable throughput (in Gbps). Double precision float value.
```

### Examples

 * `listDevices -d diag` - list all capable devices (it's different than "-d pci" option on Linux, but the output on UEFI is the same).
 * `datapathTest2 -d Device:00C0-001:00.0` - run traffic test with default parameters (RJ45 loopback, 10G rate, 1024 bytes packets).

If link partner (LKP) adapter is used, there are two possible scenarios:
 * Enable link rate and network loopback at LKP using "phyNetworkLoopback" tool, run datapathTest2 with options "--loopback NONE --interactive", press Enter in datapathTest2 to start traffic.
 * Run two instances of datapathTest2 on both sides using "--tx_only" and "--rx_only" options respectively.

### Results interpretation

Pass criteria for traffic test includes the following:
 * Number of sent and received packets are equal on host (not applicable for "--tx_only/--rx_only", it should be checked externally).
 * Number of corrupted packets (using CRC32 algorithm) is zero.
 * Tx DMA counter is equal to Rx DMA counter plus number of Rx DMA dropped packets (because Flow Control is not enabled/implemented yet).
 * Tx MSM counter is equal to Rx MSM counter (for RJ45 loopback only).
 * Other bad and error counters are zero.
 * Throughput (per each second) is acceptable. Default failure thresholds are far from nominal rate (tuned for minimal packet size 64B):
   - 10M :   4 Mbps
   - 100M:  40 Mbps
   - 1G  : 500 Mbps
   - 2.5G: 750 Mbps
   - 5G  :   1 Gbps
   - 10G :   1 Gbps

# Other Tools

## clxoverride2

Display and modify contents of Antigua .clx image.

```
Usage: clxoverride2 [-i] [-u] INPUT [OUTPUT]

Options:

    -h, --help Display help message.

    -i         Display information about provided image.
    -u         Update SHA256 hash for NCB, Security Descriptor, Customization
               Block, MAC FW, PHY FW, PCIe Serdes, KR Serdes.
    INPUT      Input .clx file.
    OUTPUT     Output .clx file. Default: INPUT.
```

### Examples

 * `clxoverride2 -i Atlantic2-0.0.18-83.clx` - print information about image `Atlantic2-0.0.18-83.clx`.
